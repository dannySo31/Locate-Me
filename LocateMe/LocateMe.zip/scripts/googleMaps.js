//google maps interface js file.
var zoomFactor = 15;
var infowindow;
var mapType = google.maps.MapTypeId.TERRAIN;
var map;
//image paths


function initialize() {
   
    var mapOptions = {
        center: new google.maps.LatLng(-34.397, 150.644),
        zoom: zoomFactor,
        mapTypeId: mapType
    };
 map = new google.maps.Map(document.getElementById("map_canvas"),
            mapOptions);

  return map;

}
function  map_zoom_in() {
    if (map.getZoom() < zoomFactor) {
        //  alert(map.getZoom());
        // zoomFactor++;
        map.setZoom(map.getZoom() + 1)
    }
}
function  map_zoom_out(){
     if (map.getZoom() > 0) {
            // zoomFactor--;
            map.setZoom(map.getZoom() - 1)
        }
}
function createHomeMarker(map, myLatlngMyLoc, sideBar) {
    var homeMarker = new google.maps.Marker({
        position: myLatlngMyLoc,
        title: 'Me'

    });
    var homeSpan = "<span class='homeSpan'>My Location</span>";
    homeMarker.setIcon(homePath);
    homeMarker.setMap(map);
   
 
   sideBar.appendChild(createSidebarEntry2(homeMarker, homeSpan, '', '', '-1', -1));
   bindInfoWindow(homeMarker, map, "<p class=infowindow><b>" + "My Location" + "</p>") 
    
    map.setCenter(myLatlngMyLoc);
}
function createMarkers(geoDataArray, sideBarName, lat, lng) {
   
    var sideBar = document.getElementById(sideBarName);
    while (sideBar.hasChildNodes()) {
        sideBar.removeChild(sideBar.lastChild);
    }
    if (isOnline == 1) {
        var myLatlng = new google.maps.LatLng(-34.397, 150.644);
        var mapOptions = {
            center: myLatlng,
            zoom: zoomFactor,
            zoomControl: true,
            mapTypeId: mapType
        };

        map = new google.maps.Map(document.getElementById("map_canvas"),
            mapOptions);
       
        var myLatlngMyLoc = new google.maps.LatLng(lat, lng);
        createHomeMarker(map, myLatlngMyLoc, sideBar);
      

    }
    for (i = 0; i < geoDataArray.length; i++) {

        var contentString = "<p class=infowindow><b>" + geoDataArray[i].name + '</b><br>Address: ' + geoDataArray[i].address + '<br>Contact Number: ' + geoDataArray[i].contact_number + '<br>Distance: ' + getDistanceDetails(geoDataArray[i].getDistance()) + " km</p>";
        if (isOnline == 1) {
            var myLatlng2 = new google.maps.LatLng(geoDataArray[i].latitude, geoDataArray[i].longitude);
            var marker = new google.maps.Marker({
                position: myLatlng2,
                title: geoDataArray[i].name
            });
            marker.setIcon(returnGeoDataImagePath(geoDataArray[i].category));
           
            marker.setMap(map);

           
            bindInfoWindow(marker, map, contentString);
        //    map.setCenter(myLatlng2);
           
        }
       
        var sideBarEntry = createSidebarEntry(marker, geoDataArray[i]);
       
        sideBar.appendChild(sideBarEntry);

    }
  
  
  
}
function bindInfoWindow(marker, map, html) {
    google.maps.event.addListener(marker, 'click', function () {
        if (infowindow) infowindow.close();
        infowindow = new google.maps.InfoWindow({ });
        infowindow.setContent(html);
        infowindow.open(map, marker);
    });
} 

function createSidebarEntry2(marker, name, address, distance, phone, category) {
    
    var div = document.createElement('div');

    var html;
    if (isOnline == true) {
        html = '<b>' + name + '</b>' + distance ;
        div.style.cursor = 'pointer';
        div.style.marginBottom = '5px';
        div.style.color = '#fff';

        google.maps.event.addDomListener(div, 'click', function () {
            google.maps.event.trigger(marker, 'click');
            map.setCenter(marker.position);
        });

        google.maps.event.addDomListener(div, 'mouseover', function () {

            div.style.color = '#fff';
        });
        google.maps.event.addDomListener(div, 'mouseout', function () {

            div.style.color = '#fff';
        });
    } else {
        html = '<b>' + name + '</b><br>' + ' Address: ' + address + '  <br>Contact Number: ' + phone;
    }
    var gPath = returnGeoDataImagePath(category);
   
    var tbl = document.createElement('table');
    var tblTr = document.createElement('tr');
    var tblTdImg = document.createElement('td');
    var tblTdDesc = document.createElement('td');

    tblTdImg.innerHTML = '<img src=' + gPath + ' />';
    tblTr.appendChild(tblTdImg);

    tblTdDesc.innerHTML = html;
    tblTr.appendChild(tblTdDesc);

    tbl.appendChild(tblTr);
    div.appendChild(tbl);
 //  div.innerHTML = html;
   
   
   
    return div;
}

function getDistanceDetails(distance) {
    return (distance / 1000).toFixed(2);
}
function createSidebarEntry(marker, geoData) {

    var div = document.createElement('div');

    var html;
    if (isOnline == true) {

        html = '<b>' + geoData.name + '</b>' + '<br>Distance: ' + getDistanceDetails(geoData.getDistance())+ ' km <br>';
        div.style.cursor = 'pointer';
        div.style.marginBottom = '5px';
        div.style.color = '#fff';

        google.maps.event.addDomListener(div, 'click', function () {
            google.maps.event.trigger(marker, 'click');
            map.setCenter(marker.position);
        });

        google.maps.event.addDomListener(div, 'mouseover', function () {

            div.style.color = '#fff';
        });
        google.maps.event.addDomListener(div, 'mouseout', function () {

            div.style.color = '#fff';
        });

       
    } else {
        html = '<b>' + geoData.name + '</b><br>' + ' Address: ' + geoData.address + '  <br>Contact Number: ' + geoData.contact_number;
        
    }

    var gPath = returnGeoDataImagePath(geoData.category);
    var tbl = document.createElement('table');
    var tblTr = document.createElement('tr');
    var tblTdImg = document.createElement('td');
    var tblTdDesc = document.createElement('td');

    tblTdImg.innerHTML = '<img src=' + gPath + ' />';
    tblTr.appendChild(tblTdImg);
   
    tblTdDesc.innerHTML = html;
    tblTr.appendChild(tblTdDesc);

    tbl.appendChild(tblTr);
    div.appendChild(tbl);


    return div;
}