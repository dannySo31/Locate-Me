//google maps interface js file.
var zoomFactor = 15;
var infowindow;
var initZoom = 13;
var map=null;
var homeMarker = null;
//interface methods
function map_zoom_in() {
    map.zoomIn();
}
function map_zoom_out() {
    map.zoomOut();
}
function createLatLng(Lat, Lng) {
    return new L.LatLng(Lat, Lng);
}
function createMapObject(Mapdiv) {
    var map2 = L.map(Mapdiv, {
        zoomControl: false
    });

    L.tileLayer('http://{s}.tile.cloudmade.com/{key}/{styleId}/256/{z}/{x}/{y}.png', {
        key: '53ea4bdfb4b948069f9bf3654ae2eda9',
        styleId: 997
    }).addTo(map2);
    
    return map2;
}
function createMarkerObject(myMap, myLatlng, title, iconPath) {
    var markerObject = L.marker(myLatlng, {
        icon: L.icon({ iconUrl: iconPath })
    });


    markerObject.addTo(myMap);

    return markerObject;
}
function onLocationFound(e) {

    alert('found');
   
}

function onLocationError(e) {
    alert(e.message);
}

function setCenter(myMap, zoom, latLng) {
    myMap.setView(latLng, zoom);
}
function createHomeMarker(myMap, myLatlngMyLoc, sideBar) {
   // myMap.on('locationfound', onLocationFound);
   // myMap.on('locationerror', onLocationError);

  //  myMap.locate({ setView: true});
   // if (homeMarker != null) {
     //   myMap.removeLayer(homeMarker);
   // }
    // homeMarker = createMarkerObject(myMap, myLatlngMyLoc, 'Me', homePath);
    if (homeMarker != null) {
        myMap.removeLayer(homeMarker)
    }
    homeMarker = L.marker(myLatlngMyLoc, {
        icon: L.icon({ iconUrl: homePath })
    });
    myMap.addLayer(homeMarker);

    var homeSpan = "My Location";

    sideBar.appendChild(createSidebarEntry2(homeMarker, homeSpan, '', '', '-1', -1));

    bindInfoWindow(homeMarker, myMap, "<p class=infowindow><b>" + "My Location" +  "<br>Accuracy: " + main_myLoc_Accuracy + " meters" + "</p>")
  //  setCenter(myMap, initZoom, myLatlngMyLoc);

}

function bindInfoWindow(marker, myMap, html) {

    marker.addTo(myMap).bindPopup(html).openPopup();
    marker.on('click', function (e) {
        setCenter(myMap, myMap.getZoom(), marker.getLatLng());
    });
    marker.closePopup();
}
function addMapListener(htmlElement, mEvent, marker, myMap, func) {

    L.DomEvent.addListener(htmlElement, mEvent, func);
}
function addMapTrigger(marker, mEvent) {
    marker.fireEvent('click');

}
//end
function initialize() {


    var latLng = createLatLng(51.505, -0.09);

    map = createMapObject('map_canvas');
    setCenter(map, initZoom, latLng);
    return map;

}



function createMarkers(geoDataArray, sideBarName, lat, lng) {
    var sideBar = document.getElementById(sideBarName);
    

    while (sideBar.hasChildNodes()) {
        sideBar.removeChild(sideBar.lastChild);
    }
    var myLatlngMyLoc = createLatLng(lat, lng);
    if (isOnline == 1) {
        var myLatlng = createLatLng(-34.397, 150.644);
        
        if (map == null) {
            var mc = document.getElementById('map_canvas');
            while (mc.hasChildNodes()) {
                mc.removeChild(mc.lastChild);
            }
            var map_container = document.createElement('div');
            map_container.setAttribute("id", "map_container");
            map_container.className='half';
            mc.appendChild(map_container);
            map = createMapObject('map_container');
            setCenter(map, initZoom, myLatlng);

        }

        
        if (showMyLocation) {
           
            createHomeMarker(map, myLatlngMyLoc, sideBar);
            
        }

    }
    for (i = 0; i < geoDataArray.length; i++) {
        var distanceData = '';

        if (showMyLocation) {
            distanceData = '<br>Distance: ' + getDistanceDetails(geoDataArray[i].getDistance()) + " km";
        }
        var contentString = "<p class=infowindow><b>" + geoDataArray[i].name + '</b><br>Address: ' + geoDataArray[i].address + '<br>Contact Number: ' + geoDataArray[i].contact_number + distanceData + "</p>";
        if (isOnline == 1) {
        
            var myLatlng2 = createLatLng(geoDataArray[i].latitude, geoDataArray[i].longitude);
            var marker = createMarkerObject(map, myLatlng2, geoDataArray[i].name, returnGeoDataImagePath(geoDataArray[i].category));

            
            bindInfoWindow(marker, map, contentString);
            if (!showMyLocation) {
              //  setCenter(map, map.getZoom(), myLatlng2);
            }
            //    map.setCenter(myLatlng2);

        }

        var sideBarEntry = createSidebarEntry(marker, geoDataArray[i]);

        sideBar.appendChild(sideBarEntry);

    }
    if (isOnline == 1) {
        $('#divBottom').show();
        showSideBars(true);
    }
    if (map == null) {

        setCenter(map, initZoom, myLatlngMyLoc);
    }
    else {

        setCenter(map, map.getZoom(), myLatlngMyLoc);
    }



}

function createSidebarEntry2(marker, name, address, distance, phone, category) {

    var div = document.createElement('div');

    var html;
    if (isOnline == true) {
        html = '<b>' + name + '</b>' + distance;
     //   div.style.cursor = 'pointer';
      //  div.style.marginBottom = '5px';
       // div.style.color = '#000000';
        div.className = 'sideBarDiv';
        addMapListener(div, 'click', marker, map, function () {
            addMapTrigger(marker, 'click');

           // setCenter(map, initZoom, marker.getLatLng());

        });

        addMapListener(div, 'mouseover', marker, map, function () {

          //  div.style.color = '#fff';
        });
        addMapListener(div, 'mouseout', marker, map, function () {

            //div.style.color = '#fff';
        });

    } else {
        html = '<span class="oTitle">' + geoData.name + '</span><br>' + ' Address: ' + address + '  <br>Contact Number: ' + phone;
    }
    var gPath = returnGeoDataImagePath(category);

    var tbl = document.createElement('table');
    var tblTr = document.createElement('tr');
    var tblTdImg = document.createElement('td');
    var tblTdDesc = document.createElement('td');

    tblTdImg.style.width = '50px';
    tblTdImg.innerHTML = '<img src=' + gPath + ' />';
    tblTr.appendChild(tblTdImg);

    tblTdDesc.innerHTML = html;
    tblTr.appendChild(tblTdDesc);

    tbl.appendChild(tblTr);
    div.appendChild(tbl);
    //  div.innerHTML = html;



    return div;
}

function getDistanceDetails(distance) {
    return (distance / 1000).toFixed(2);
}
function createSidebarEntry(marker, geoData) {

    var div = document.createElement('div');

    var html;
    if (isOnline == true) {
        var distanceData = '';
        if (showMyLocation) {
            distanceData = '<br>Distance: ' + getDistanceDetails(geoData.getDistance()) + ' km <br>';
        }
        html = '<b>' + geoData.name + '</b>' + distanceData;
        div.className = 'sideBarDiv';
        //div.style.cursor = 'pointer';
       // div.style.marginBottom = '5px';
       // div.style.color = '#000000';

        addMapListener(div, 'click', marker, map, function () {
            addMapTrigger(marker, 'click');

           //

        });

        addMapListener(div, 'mouseover', marker, map, function () {

         //   div.style.color = '#fff';
        });
        addMapListener(div, 'mouseout', marker, map, function () {

           // div.style.color = '#fff';
        });




    } else {
        html = '<span class="oTitle">' + geoData.name + '</span><br>' + ' Address: ' + geoData.address + '  <br>Contact Number: ' + geoData.contact_number;

    }

    var gPath = returnGeoDataImagePath(geoData.category);
    var tbl = document.createElement('table');
    var tblTr = document.createElement('tr');
    var tblTdImg = document.createElement('td');
    var tblTdDesc = document.createElement('td');
    tblTdImg.style.width = '50px';
    tblTdImg.innerHTML = '<img src=' + gPath + ' />';
    tblTr.appendChild(tblTdImg);

    tblTdDesc.innerHTML = html;
    tblTr.appendChild(tblTdDesc);

    tbl.appendChild(tblTr);
    div.appendChild(tbl);


    return div;
}