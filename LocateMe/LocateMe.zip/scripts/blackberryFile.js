

function BB_pay(digitalGoodID, digitalGoodSKU, digitalGoodName, digitalGoodDesc, purchaseAppName, purchaseAppIcon) {

    try {
        blackberry.payment.purchase({
            "digitalGoodID": digitalGoodID,
            "digitalGoodSKU": digitalGoodSKU,
            "digitalGoodName": digitalGoodName,
            "metaData": digitalGoodDesc,
            "purchaseAppName": purchaseAppName,
            "purchaseAppIcon": purchaseAppIcon
        },
      BB_success, BB_failure);
    } catch (e) {
        alert("Error" + e);
    }
}

function BB_success(purchase) {
    var purchasedItem = JSON.parse(purchase);
    var transId = purchasedItem.transactionID;
    var sku = purchasedItem.digitalGoodSKU;
    var dgId = purchasedItem.digitalGoodID;

    if (transId != null) {
        alert("Purchased Item: " + transId + "," + sku + "," + dgId);
        db_unlockCity(purchasedItem.digitalGoodSKU);
        $('#divPurchase').slideToggle('slow');
    } 
}

function BB_failure(errorText, errorId) {
    alert("Error occured: " + errorText + ", " + errorId);
}