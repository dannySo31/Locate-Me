


//overhaul

var locateDB = null;

function db_init() {
    
    db_initDatabase();
}
function db_initDatabase() {
    
    try {
        if (!window.openDatabase) {
            alert('Databases are not supported in this browser.');
        } else {
            var shortName = 'LocateMeDB';
            var version = '1.0';
            var displayName = 'LocateMe Database';
            var maxSize = 50 * 1024 * 1024; //  bytes  

            locateDB = openDatabase(shortName, version, displayName, maxSize);
            
            db_createTables();
           
        }  
    } catch (e) {
        if (e == 2) {
            // Version number mismatch.  
            console.log("Invalid database version.");
        } else {
            console.log("Unknown error " + e + ".");
        }
        return;  
    }
}

function db_intitializeData() {
   
        locateDB.transaction(
        function (transaction) {
            transaction.executeSql("Select id from location LIMIT 5", [], db_dataSelectHandler, errorHandler);
        });


    }


    function db_dataSelectHandler(transaction, results) {
       
        if (results.rows.length <= 0) {
           // alert(results.rows.length);
           // db_deleteData();
            db_prePopulateData();
        }
       
        main_init();
    }
    function db_createTables() {
        // db_dropTables();
        // db_deleteData();
        
    locateDB.transaction(function (transaction) {
        transaction.executeSql('CREATE TABLE IF NOT EXISTS location(id INTEGER PRIMARY KEY, name TEXT, address TEXT, category INTEGER, cityCode INTEGER, latitude TEXT, longtitude TEXT, contact_number TEXT, added_on DATETIME);', []);
        transaction.executeSql('CREATE TABLE IF NOT EXISTS City(id INTEGER PRIMARY KEY, name TEXT,cityCode INTEGER, added_on DATETIME, isLocked bit, price FLOAT, digitalGoodID TEXT, digitalGoodSKU TEXT, digitalGoodName TEXT);', []);
    });
    db_intitializeData();
   
    
}
function nullDataHandler(tx, result) {
   //alert('null Data');
   
}

function errorHandler(tx, error) {
    alert(error.message);
}
function insertPoliceStations() {
    db_insertLocation('Precinct II - Guadalupe Nuevo', 'Sgt. Fabian, Yabut Circle, Makati', 4, '14.564125', '121.045901', '-', 1);
    db_insertLocation('Precinct III - Bangkal', 'P. Santos St. cor. Evangelista St., Makati', 4, '14.570293', '121.044565', '-', 1);
    db_insertLocation('Precinct VII - West Rembo', 'J.P. Rizal Ext., Makati', 4, '14.551103', '121.063453', '-', 1);
    db_insertLocation('Precinct IX - Poblacion', 'San Mateo St. cor. P. Gomez St., Makati', 4, '14.561445', '121.07489', '-', 1);
}

function insertSchools() {
    db_insertLocation('AMA Computer College', 'Bangkal, Makati City, Philippines', 5, 14.548922, 121.012277, '+63 2 844 3225', 1);
    db_insertLocation('Assumption College, Inc.', 'San Lorenzo Drive, San Lorenzo Village ', 5, '14.548299', '121.021203', '+63 2 893-04-24', 1);
    db_insertLocation('Asia Pacific College', '3 Humabon Place, Magallanes, Makati City', 5, 14.548922, 121.012277, '+632 8529232', 1);
    db_insertLocation('Asian Institute of Management', '123 Paseo de Roxas, Legaspi Village, Makati City', 5, 14.552951, 121.018693, '+632 892-40-22 loc 214', 1);
    db_insertLocation('Ateneo Professional Schools', '20 Rockwell Drive, Rockwell Center, Makati City', 5, 14.565558, 121.035506, '+632 899-43-43', 1);
    db_insertLocation('Bethany Baptist Academy, Inc.', '1716 Dian St. Palanan', 5, 14.533739, 121.021773, '-', 1);
    db_insertLocation('Colegio de Sta. Rosa.', '6321 Estrella St., Guadalupe Viejo', 5, '14.563813', '121.039784', '+632 846-49-70', 1);
    db_insertLocation('Colegio de San Agustin', 'Carissa St., Dasmari�as Village , Dasmari�as, Makati City', 5, '14.543708', '121.025365', '-', 1);
    db_insertLocation('Don Bosco Technical Institute', 'Chino roces Ave., San Lorenzo ', 5, '14.550687', '121.01453', '-', 1);
    db_insertLocation('International Montessori School', '4 Ipil Place Forbes Park', 5, '14.542712', '121.043841', '-', 1);
    db_insertLocation('Singapore School Manila', 'Paseo de Magallanes, Magallanes', 5, '14.537166', '121.018092', '-', 1);
    db_insertLocation('Spurgeon School Foundation, Inc.', '140 Dela Costa, Salcedo Village, Bel-Air', 5, '14.561715', '121.017813', '-', 1);
    db_insertLocation('SAsia Pacific College', '3, Makati City 1232', 5, '14.531786', '121.021393', '-', 1);
}

function insertGasolineStations() {
    db_insertLocation('Caltex Olympia', 'Olympia, Makati City', 2, '14.571954', '121.01894', '-', 1);
    db_insertLocation('Caltex San Antonio', 'San Antonio, Makati City', 2, '14.562235', '121.010701', '-', 1);
    db_insertLocation('Caltex Bel-Air', 'Barangay Bel-Air, Makati City', 2, '14.560573', '121.039711', '-', 1);
    db_insertLocation('Caltex Paseo de Roxas', 'Ayala Triangle Gardens Paseo de Roxas', 2, '14.557666', '121.024691', '-', 1);
    db_insertLocation('Caltex Pio del Pilar', 'Pio del Pilar, Makati City', 2, '14.552598', '121.010615', '-', 1);
    db_insertLocation('Caltex San Isidro', 'Barangay San Isidro, Makati City', 2, '14.552681', '121.007782', '-', 1);
    db_insertLocation('Caltex EDSA', 'Barangay Magallanes, Makati City', 2, '14.559618', '121.039914', '-', 1);
}

function insertATMS() {
    db_insertLocation('RCBC Poblacion', 'Barangay Poblacion, Makati City', 1, '14.569794', '121.030354', '-', 1);
    db_insertLocation('RCBC Bel-Ai', 'Barangay Bel-Ai, Makati City', 1, '14.56265', '121.016364', '-', 1);
    db_insertLocation('RCBC San Antonio', 'Barangay San Antonio, Makati City', 1, '14.561819', '121.010613', '-', 1);
    db_insertLocation('RCBC Pio del Pilar', 'Barangay Pio del Pilar, Makati City', 1, '14.554924', '121.013274', '-', 1);
    db_insertLocation('BDO Bel-Air', 'Barangay Bel-Air, Makati City', 1, '14.559992', '121.017809', '-', 1);
    db_insertLocation('BDO Dasmari�as', 'Barangay Dasmari�as, Makati City', 1, '14.5354', '121.024332', '-', 1);
    db_insertLocation('BDO Poblacion', 'Barangay Poblacion, Makati City', 1, '14.566637', '121.034288', '-', 1);
    db_insertLocation('BDO Barangka', 'Barangay Barangka, Makati City', 1, '14.56996', '121.036692', '-', 1);
    db_insertLocation('BDO Bangkal', 'Barangay Bangkal, Makati City', 1, '14.547032', '121.011114', '-', 1);
}

function insertFireStations() {
    db_insertLocation('Makati Fire Station', 'A. Mabini Street, Poblacion, Makati City, Metro Manila Philippines', 6, '14.569296', '121.033532', '-', 1);
    db_insertLocation('Makati Central Fire Station', '2/F Makati Central Fire Station, Ayala Avenue extension corner Malugay St. Makati City 1203, Philippines', 6, '14.564976', '121.015507', '+632 893 9977', 1);
    db_insertLocation('Balagtas Fire Station', 'Batangas Makati City, Philippines', 6, 14.553096, 121.00701, '-', 1);
}

function insertHospitals() {
    db_insertLocation('Ma. Lourdes Maternity Hospital', '196 Pasong Tamo, Solchuaga, Makati City, Philippines', 3, 14.571248, 121.01468, '+632 895-3846/47', 1);
    db_insertLocation('Ospital ng Makati Acute Care Center', 'Malugay St., Bel-Air, Makati City', 3, 14.563003, 121.01747, '+632 813-53-99', 1);
    db_insertLocation('St. Clares Medical Center', '1838 Dian Street, Makati City', 3, 14.564228, 121.00118, '+632 831-6511',1);
    db_insertLocation('Makati Medical Center', 'Amorsolo St., A. Lorenzo San Lorenzo Village, Makati City', 3, 14.556835, 121.014649, '+632 895-3846/47', 1);
    db_insertLocation('M-Tech Medical Hospital, Diagnostic and Therapeutic Center', '12/F Goodland Bldg., 379 Gil Puyat Avenue', 3, 14.560947, 121.030344, '+632 898-2663/65', 1);
    db_insertLocation('Ospital ng Makati', 'Sampaguita St., Pembo, Makati City', 3, 14.546969, 121.061865, '+632 8882-63-16', 1);
    db_insertLocation('Army General Hospital', 'Fort Bonifacio, Makati City', 3, 14.535733, 121.048196, '+632 911-6001', 1);
   
}
function db_prePopulateData() {
    
    db_insertCity('Makati City, PH', 1,false,1,'LM00','SDLM00','LM_Makati_PH');
    db_insertCity('Manila, PH', 2, true, 1, 'LM01','SDLM01', 'LM_Manila_PH');
    db_insertCity('Mandaluyong City, PH', 3,true,1,'SDLM02','LM02','LM_Mandaluyong_PH');
    db_insertCity('Pasig City, PH', 4,true,1,'LM03','SDLM03','LM_Pasig_PH');
    db_insertCity('Marikina City, PH', 5,true,1,'LM04','SDLM04','LM_Marikina_PH');
    db_insertCity('Quezon City, PH', 6, true, 1, 'LM05','SDLM05', 'LM_QC_PH'); 
    db_insertCity('Caloocan, PH', 7, true, 1,'LM06','SDLM06','LM_CAL_PH');
    db_insertCity('Alabang, PH', 8, true, 1,'LM07','SDLM07','LM_Alabang_PH');
    db_insertCity('Taguig City, PH', 9, true, 1, 'LM08','SDLM08', 'LM_Taguig_PH');
    //POLICE
    insertPoliceStations();

    //Schools
    insertSchools();

    //gASOLIne Stations
    insertGasolineStations();
   

    //ATM
    insertATMS();

    //fireStations

    insertFireStations();

    //Hospitals

    insertHospitals();
    
  

}
function db_insertCity(name, cityCode, isLocked, price, digitalGoodId, digitalGoodSKU, digitalGoodName) {
   
    locateDB.transaction(function (transaction) {
        var addedOn = new Date();
        transaction.executeSql("INSERT INTO City(name ,cityCode, added_on, isLocked, price, digitalGoodId, digitalGoodSKU, digitalGoodName) VALUES (?,?,?,?,?,?,?,?)",
             [name, cityCode, addedOn, isLocked, price, digitalGoodId, digitalGoodSKU, digitalGoodName]);
    });
}
function db_insertLocation(name, address, category, latitude, longtitude, contact_number, cityCode) {
    locateDB.transaction(function (transaction) {
        var addedOn = new Date();
        transaction.executeSql("INSERT INTO location(name , address, category, cityCode, latitude,longtitude, contact_number, added_on) VALUES (?,?,?,?,?,?,?,?)",
             [name, address, category, cityCode, latitude, longtitude, contact_number, addedOn]);
    });
}
function db_unlockCity(code) {
    locateDB.transaction(function (transaction) {
        var addedOn = new Date();
        transaction.executeSql("UPDATE City set isLocked='false' Where digitalGoodSKU = ?",
             [code]);
    });
}

function db_dropTables() {
    locateDB.transaction(
        function (transaction) {
            transaction.executeSql("DROP TABLE location;", [], nullDataHandler, errorHandler);
            transaction.executeSql("DROP TABLE city;", [], nullDataHandler, errorHandler);
        }
    );

    }

    function db_deleteData() {
        locateDB.transaction(
        function (transaction) {
            transaction.executeSql("DELETE from location;", [], nullDataHandler, errorHandler);
            transaction.executeSql("DELETE from city;", [], nullDataHandler, errorHandler);
        }
    );
    }



    
   

   