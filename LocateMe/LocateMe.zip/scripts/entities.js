
function geoData(latitude, longitude, name, address, contact_number, category, cityCode) {
    this.latitude = latitude;
    this.longitude = longitude;
    this.name = name;
    this.address = address;
    this.contact_number = contact_number;
    this.category = category;
    this.cityCode = cityCode;
}
//geoData.prototype.distance=null;
function setGeoDataDistance(value) {

    this.distance = value;
}
function getGeoDataDistance() {
    return this.distance;
}

geoData.prototype.getDistance = getGeoDataDistance;
geoData.prototype.setDistance = setGeoDataDistance;


function City(name, cityCode, isLocked,price) {
    this.name = name;
    this.cityCode = cityCode;
    this.isLocked = isLocked;
    this.price = price;
}

//common functions

var atmPath = 'images/atm.png';
var gasStationPath = 'images/gasStation.png';
var hospitalPath = 'images/hospital.png';
var homePath = 'images/MyLocation.png';
var policePath = 'images/police.png';
var schoolPath = 'images/school.png';
var fireStationPath = 'images/fireStation.png';

var hotelPath = 'images/hotel.png';

var pharmacyPath = 'images/pharmacy.png';


function returnGeoDataImagePath(categoryId) {
    switch (parseInt(categoryId)) {
        case -1:
            return homePath;
            break;
        case 1:
            return atmPath;
            break;
        case 2:
            return gasStationPath;
            break;
        case 3:
            return hospitalPath;
            break;
        case 4:
            return policePath;
            break;
        case 5:
            return schoolPath;
            break;
        case 6:
            return fireStationPath;
            break;
        case 7:
            return pharmacyPath;
            break;
        case 8:
            return hotelPath;
            break;
    }
}

function loadjscssfile(filename, filetype) {
    if (filetype == "js") { //if filename is a external JavaScript file
        var fileref = document.createElement('script')
        fileref.setAttribute("type", "text/javascript")
        fileref.setAttribute("src", filename)
    }
    else if (filetype == "css") { //if filename is an external CSS file
        var fileref = document.createElement("link")
        fileref.setAttribute("rel", "stylesheet")
        fileref.setAttribute("type", "text/css")
        fileref.setAttribute("href", filename)
    }
    if (typeof fileref != "undefined")
        document.getElementsByTagName("head")[0].appendChild(fileref)
}