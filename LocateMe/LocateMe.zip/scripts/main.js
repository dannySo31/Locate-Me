var isOnline = 1; //true
var categoryIdGlobal = 0;
var findLocationBtn = $("#btnMyLocation");
var map_canvas = $('#map_canvas');
var sideBar = $('#sidebar');
var sideBar2 = $('#sidebar2');
var myGlobalLatitude=0;
var myGlobalLongitude=0;
var delay = 5000;
var CITYCODE;
var timerVar;
var geoTimeOut = 5000;
var showMyLocation = true;
var main_setAccracy = 50;
var main_myLoc_Accuracy = 0;
var currency = '$';
var APP_NAME = "Locate Me!";

$(function () {
    
    $('#Loading').hide();

    db_init();



});
function main_init() {
    blackberry.payment.developmentMode = true;
    loadCities();
    showInitContainer();

   
    //  timerVar = setInterval(CheckIfOnline, parseInt(delay));
    $('#divBottom').hide();
    $('#topSection').hide();

    $('#divSave').click(function () {
        saveSettings();
    });

//    $('#savePurChase').click(function () {
//        savePurchaseSettings();
//       
//    });
    $('#btnAbout').click(function () {
        $('#divAbout').slideToggle('slow', function () {
            $('#divLocateMe').hide();
            $('#divSettings').hide();
            $('#divPurchase').hide();
            $('#divSelectCity').hide();
            $('#optionsPane').hide();
        });

    });
    $('#btnPurchase').click(function () {
        $('#divPurchase').slideToggle('slow', function () {
            $('#divLocateMe').hide();
            $('#divSettings').hide();
            $('#divAbout').hide();
            $('#divSelectCity').hide();
            $('#optionsPane').hide();
        });
        clearDiv(document.getElementById('divPurchasePanel'));
        loadPurchasePanelCityList();

    });
    $('#btnLocate').click(function () {
        $('#divLocateMe').slideToggle('slow', function () {
            $('#divPurchase').hide();
            $('#divSettings').hide();
            $('#divAbout').hide();
            $('#divSelectCity').hide();
            $('#optionsPane').hide();
        });

    });
    $('#btnSettings').click(function () {
        //  $('#divBottom').hide();
        // $('#optionsPane').hide();

        $('#divSettings').slideToggle('slow', function () {
            $('#divPurchase').hide();
            $('#divLocateMe').hide();
            $('#divAbout').hide();
            $('#divSelectCity').hide();
            $('#optionsPane').hide();
        });

    });
    $('#btnCategories').click(function () {
        showCategories();
    });
    $('#divShowHideSideBar').click(function () {
        sideBar.animate({ bottom: 'toggle' }, 500);
        sideBar2.slideToggle('normal');
        if($('#map_container').hasClass('half')){
            $('#map_container').removeClass('half');
            $('#map_container').addClass('whole');
        }  else{
            $('#map_container').addClass('half');
            $('#map_container').removeClass('whole');
        }
        map.invalidateSize(true);
        
    });

    $('#btnChangeCity').click(function () {


        $('#divSelectCity').slideToggle('slow', function () {
            $('#divSettings').hide();
            $('#divPurchase').hide();
            $('#divLocateMe').hide();
            $('#divAbout').hide();
            $('#optionsPane').hide();
        });
        clearDiv(document.getElementById('divCitiesPanel'));
        loadPanelCityList();
        // $('#divBottom').hide();
        // $('#topSection').hide();
        // showInitContainer();
    });



    $('#btnPurchase').click(function () {
        // db_dropTables();
    });


    $('#divZoomIn').click(function () {
        map_zoom_in();
    });
    $('#divZoomOut').click(function () {
        map_zoom_out();
    });
}
function savePurchaseSettings() {

    $('#divPurchasePanel .purchased input[type=hidden]').each(function () {
        var x = parseInt($(this).val());
        locateDB.transaction(
        function (transaction) {
            transaction.executeSql("Select * from city where isLocked='true' and cityCode=" + x + ';', [], dataPurchaseCityPayHandler, errorHandler2);
        });

    });
   
}
function dataPurchaseCityPayHandler(transaction, results) {
    //alert(results.rows.length);
    for (var i = 0; i < results.rows.length; i++) {
        var row = results.rows.item(i);
        BB_pay(row['digitalGoodId'], row['digitalGoodSKU'], row['digitalGoodName'], APP_NAME + ': Purchased ' + row['name'] + ' on ' + new Date(), APP_NAME, null);
    }
}

function saveSettings() {

    geoTimeOut = parseInt($('#timeOutSelect').val()) * 1000
    main_setAccracy = parseInt($('#accuracySelect').val());
    $('#divSettings').slideToggle('slow');

}
function showCategories() {

    $('#optionsPane').slideToggle('slow', function () {
        
        $('#divSettings').hide();
        $('#divPurchase').hide();
        $('#divLocateMe').hide();
        $('#divAbout').hide();
        $('#divSelectCity').hide();
    });
}
function hideAll() {
    $('#divBottom').hide();
    $('#optionsPane').hide();
    $('#divSettings').hide();
}
function showInitContainer() {
    $('#initContainer').show('slow');
    $('#container').hide();
    $('#optionsPane').hide();
    $('#logoDiv').hide();
}
function clearDiv(oDiv) {
    while (oDiv.hasChildNodes()) {
        oDiv.removeChild(oDiv.lastChild);
    }
}
function getLocationList(catType) {
    map = null;
    $('#Loading').show();
    $('#divBottom').hide();
    categoryIdGlobal = catType;

    $('#optionsPane').slideToggle('slow');
    CheckIfOnline();

}
function returnOnlineStatus() {
    $('#Loading').text('Status: Online, attempting to get location....');
    $('#onlinePane').show();
    $('#offlinePane').hide();
   // $('#options').show();

    isOnline = 1;
   
    getPosition('');
}
function showSideBars(flag) {
    if (flag) {
        sideBar.show();
        sideBar2.show();
    } else {
        sideBar.hide();
        sideBar2.hide();
    }
}
function returnOfflineStatus() {
    $('#Loading').text('Status: Offline, Loading....');
    $('#onlinePane').hide();
    $('#offlinePane').show();
   // $('#options').hide();
    isOnline = 0;
    getLocationsByCategory2(categoryIdGlobal);
}
function CheckIfOnline() {
    $('#Loading').text('');
    tempImage = new Image();
    tempImage.onload = returnOnlineStatus;
    tempImage.onerror = returnOfflineStatus;
    var imgSrc = 'http://www.google.co.uk/intl/en_uk/images/logo.gif';        // this must point to the url of a valid image.
    tempImage.src = imgSrc + '?randParam=' + new Date().getTime();   

}


//Database access

function getLocationsByCategory(categoryID, lat, lng) {

    myGlobalLatitude = lat;
    myGlobalLongitude = lng;
    
    try {
        locateDB.transaction(
        function (transaction) {
            transaction.executeSql(getSqlSelect(categoryID), [], dataSelectHandler, errorHandler2);
        });
     


        
    } catch (err) {
 
    }

}

function getSqlSelect(categoryID) {
    var sql;
    if (parseInt(categoryID) == 0) {
        sql = "SELECT * FROM location where cityCode=" + parseInt(CITYCODE) + ';';
    } else {
        sql = "SELECT * FROM location where category=" + parseInt(categoryID) + ' and cityCode= ' +  + parseInt(CITYCODE) + ';';
    }

    return sql;
}
function errorHandler2(tx, error) {
    alert(error.message);
}
function dataSelectHandler(transaction, results) {
    try {
        var geoDataArray = [];
        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);
            geoDataArray[i] = new geoData(row['latitude'], row['longtitude'], row['name'], row['address'], row['contact_number'], row['category'], row['cityCode']);
            geoDataArray[i].setDistance(distanceBetweenPoints(geoDataArray[i].latitude, geoDataArray[i].longitude, myGlobalLatitude, myGlobalLongitude));
           
        }
    } catch (err) { }
    
    geoDataArray.sort(function (a, b) {
        return a.getDistance() - b.getDistance();
    });
    $('#Loading').hide();
    createMarkers(geoDataArray, 'sidebar2', myGlobalLatitude, myGlobalLongitude);

}
function getLocationsByCategory2(categoryID) {

    var geoDataArray = [];
   
   locateDB.transaction(
        function (transaction) {
            transaction.executeSql(getSqlSelect(categoryID), [], dataSelectHandlerOffline, errorHandler2);
        });
}

function dataSelectHandlerOffline(transaction, results) {
    var lat = 0.12;
    var lng = -2.1;
    $('#Loading').hide();
    try {
        var geoDataArray = [];
        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);
            geoDataArray[i] = new geoData(row['latitude'], row['longtitude'], row['name'], row['address'], row['contact_number'], row['category'], row['cityCode']);
           

        }
    } catch (err) { }


    createMarkers(geoDataArray, 'offliNeInnerPane', lat, lng);
}
function loadPurchasePanelCityList() {
   // $('#totalPrice').text('0.00');
    $('#currency').text(currency);
    locateDB.transaction(
        function (transaction) {
            transaction.executeSql("Select * from city where isLocked='true'", [], dataPurchaseCityPanelHandler, errorHandler2);
        });
    }
    function dataPurchaseCityPanelHandler(transaction, results) {
        var cityDiv = document.getElementById('divPurchasePanel');

        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);
            var cityObject = document.createElement('div');
            cityObject.innerHTML = "<div class='floatName'>" + row['name'] + "<input type='hidden' value='" + row['cityCode'] + "'/>" + "</div><div class='priceText'>" + currency + parseFloat(row['price']).toFixed(2) + '</div>';
            cityObject.className = 'cityPanelObject';
            cityObject.setAttribute('id', 'city' + row['cityCode']);

            cityObject.onclick = function (a, b,c) {
                return function () {
                    processCity3(a, b,c);
                }
            } (row['cityCode'], row['name'], row['price']);
            cityDiv.appendChild(cityObject);
        }

    }
    function processCity3(code, name, price) {
      
      // var total = parseFloat($('#totalPrice').text());
        if ($('#city' + code).hasClass('purchased')) {
            $('#city' + code).removeClass('purchased');
//            total = total - parseFloat(price);

        } else {
            $('#city' + code).addClass('purchased');
            savePurchaseSettings();
       //     total = parseFloat(total) + parseFloat(price);
        }
        //        $('#totalPrice').text(total.toFixed(2));
       
    }
function loadPanelCityList() {
    locateDB.transaction(
        function (transaction) {
            transaction.executeSql("Select * from city where isLocked='false'", [], dataSelectCityPanelHandler, errorHandler2);
        });
}
function loadCities() {
  
    locateDB.transaction(
        function (transaction) {
            transaction.executeSql("Select * from city where isLocked='false'", [], dataSelectCityHandler, errorHandler2);
        });
    }
    
    function dataSelectCityPanelHandler(transaction, results) {
        var cityDiv = document.getElementById('divCitiesPanel');

        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);
            var cityObject = document.createElement('div');
            cityObject.innerHTML = row['name'];
            cityObject.className = 'cityPanelObject cityBg';

            cityObject.onclick = function (a, b) {
                return function () {
                    processCity2(a, b);
                }
            } (row['cityCode'], row['name']);
            cityDiv.appendChild(cityObject);
        }
       
    }

function dataSelectCityHandler(transaction, results) {
    var cityDiv = document.getElementById('divCities');
    
    for (var i = 0; i < results.rows.length; i++) {
        var row = results.rows.item(i);
        var cityObject = document.createElement('div');
        cityObject.innerHTML = row['name'];
        cityObject.className = 'cityPanelObject cityBg';
     
        cityObject.onclick = function (a, b) {
            return function () {
                processCity(a,b);
            }
        } (row['cityCode'], row['name']);
        cityDiv.appendChild(cityObject);
    }
    $('#spnLoader').hide();
   
}
function processCity(citycode, name) {
   
    CITYCODE = citycode;
    $('#initContainer').hide();
    $('#container').show('slow');
    $('#optionsPane').slideDown();
    $('#topSection').show();
    $('#spanCity').text(name);
    $('#divPurchase').hide();
    $('#divLocateMe').hide();
    $('#divSettings').hide();
    $('#divAbout').hide();
    $('#divSelectCity').hide();
    //  initialize();
    $('#logoDiv').show();
    showSideBars(false);
}
function processCity2(citycode, name) {

    CITYCODE = citycode;
    $('#spanCity').text(name);

    $('#divSelectCity').slideToggle('slow', function () {
        $('#divSettings').hide();
        $('#divPurchase').hide();
        $('#divLocateMe').hide();
        $('#divAbout').hide();
        $('#optionsPane').hide();
    });
}

function main_showPopup(message, title) {
    jAlert(message, title);
}